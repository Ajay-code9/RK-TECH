import React, { useEffect } from 'react'
import Lamp from '../components/Lamp'
import Footer from '../components/Footer'

const Contact = () => {
  return (
    <div>
        <Lamp/>
        <Footer/>
    </div>
  )
}

export default Contact